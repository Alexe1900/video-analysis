# hanoi > 2025-07-19 5:04pm
https://universe.roboflow.com/hanoi1/hanoi

Provided by a Roboflow user
License: CC BY 4.0

