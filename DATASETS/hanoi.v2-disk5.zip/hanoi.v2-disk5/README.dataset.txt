# hanoi > disk1-3
https://universe.roboflow.com/hanoi1/hanoi

Provided by a Roboflow user
License: CC BY 4.0

